import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "path";
import fs from "fs";
import { handleDemo } from "./routes/demo";
import { connectMongo } from "./db";
import { listProjects, postProject, upload } from "./routes/projects";
import { searchFreelancers } from "./routes/freelancers";
import { listCategories, getCategory, trackCategory } from "./routes/categories";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Ensure uploads dir exists and serve it
  const uploadDir = path.join(process.cwd(), "uploads");
  if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
  app.use("/uploads", express.static(uploadDir));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // DB (optional)
  connectMongo().catch(() => {
    console.log("MongoDB not configured - using in-memory stores.");
  });

  // Project routes
  app.post("/api/projects", upload.array("files", 8), postProject);
  app.get("/api/projects", listProjects);

  // Freelancers search
  app.get("/api/freelancers", searchFreelancers);

  // Categories
  app.get("/api/categories", listCategories);
  app.get("/api/categories/:slug", getCategory);
  app.post("/api/categories/:slug/track", trackCategory);

  return app;
}
