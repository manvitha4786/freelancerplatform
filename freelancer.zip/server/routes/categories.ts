import type { RequestHandler } from "express";
import { z } from "zod";
import { CategoryModel, isCategoryMongoReady } from "../schemas/category";

// Memory fallback dataset
const MEMORY_CATEGORIES = [
  { slug: "web-dev", name: "Web Development", description: "Front-end, back-end, and full‑stack web projects.", icon: "Globe", colorFrom: "#0ea5e9", colorTo: "#6366f1", projectCount: 1243, hireCount: 532, viewCount: 9213, trendingScore: 0 },
  { slug: "mobile-apps", name: "Mobile Apps", description: "iOS, Android, and cross‑platform apps.", icon: "Smartphone", colorFrom: "#10b981", colorTo: "#14b8a6", projectCount: 884, hireCount: 451, viewCount: 7120, trendingScore: 0 },
  { slug: "ui-ux", name: "UI/UX Design", description: "Design systems, flows, and prototypes.", icon: "Palette", colorFrom: "#f43f5e", colorTo: "#ec4899", projectCount: 760, hireCount: 389, viewCount: 6450, trendingScore: 0 },
  { slug: "ai-ml", name: "AI & ML", description: "Models, MLOps, and data science.", icon: "Brain", colorFrom: "#8b5cf6", colorTo: "#d946ef", projectCount: 546, hireCount: 312, viewCount: 5981, trendingScore: 0 },
  { slug: "data-analytics", name: "Data & Analytics", description: "Pipelines, warehousing, and BI.", icon: "BarChart3", colorFrom: "#f59e0b", colorTo: "#ea580c", projectCount: 612, hireCount: 273, viewCount: 4821, trendingScore: 0 },
  { slug: "marketing", name: "Marketing", description: "Growth, SEO, and performance.", icon: "Megaphone", colorFrom: "#3b82f6", colorTo: "#06b6d4", projectCount: 694, hireCount: 201, viewCount: 4102, trendingScore: 0 },
];

const ListQuery = z.object({
  q: z.string().optional(),
  sort: z.enum(["trending", "popular", "name"]).optional().default("trending"),
  limit: z.coerce.number().min(1).max(100).optional().default(24),
});

export const listCategories: RequestHandler = async (req, res) => {
  const parsed = ListQuery.safeParse(req.query);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { q, sort, limit } = parsed.data;

  if (isCategoryMongoReady()) {
    const filter: any = {};
    if (q) filter.$text = { $search: q };

    const sortMap: Record<string, any> = {
      trending: { trendingScore: -1, updatedAt: -1 },
      popular: { projectCount: -1, hireCount: -1, viewCount: -1 },
      name: { name: 1 },
    };

    const items = await CategoryModel.find(filter).sort(sortMap[sort]).limit(limit).lean();
    return res.json({ items });
  }

  // Memory fallback
  let items = MEMORY_CATEGORIES.slice();
  if (q) {
    const ql = q.toLowerCase();
    items = items.filter((c) => (c.name + " " + c.description).toLowerCase().includes(ql));
  }
  const sorters: Record<string, (a: any, b: any) => number> = {
    trending: (a, b) => (b.projectCount * 3 + b.hireCount * 5 + b.viewCount) - (a.projectCount * 3 + a.hireCount * 5 + a.viewCount),
    popular: (a, b) => (b.projectCount + b.hireCount + b.viewCount) - (a.projectCount + a.hireCount + a.viewCount),
    name: (a, b) => a.name.localeCompare(b.name),
  };
  items.sort(sorters[sort]);
  return res.json({ items: items.slice(0, limit) });
};

const IdParam = z.object({ slug: z.string().min(1) });

export const getCategory: RequestHandler = async (req, res) => {
  const params = IdParam.safeParse(req.params);
  if (!params.success) return res.status(400).json({ error: params.error.flatten() });
  const { slug } = params.data;

  if (isCategoryMongoReady()) {
    const cat = await CategoryModel.findOne({ slug }).lean();
    if (!cat) return res.status(404).json({ error: "Not found" });
    return res.json({ category: cat });
  }
  const cat = MEMORY_CATEGORIES.find((c) => c.slug === slug);
  if (!cat) return res.status(404).json({ error: "Not found" });
  return res.json({ category: cat });
};

const TrackBody = z.object({ type: z.enum(["view", "hire", "project"]) });

export const trackCategory: RequestHandler = async (req, res) => {
  const params = IdParam.safeParse(req.params);
  const body = TrackBody.safeParse(req.body);
  if (!params.success || !body.success) return res.status(400).json({ error: (!params.success ? params.error.flatten() : body.error.flatten()) });
  const { slug } = params.data;
  const { type } = body.data;

  if (isCategoryMongoReady()) {
    const inc: any = {};
    if (type === "view") inc.viewCount = 1;
    if (type === "hire") inc.hireCount = 1;
    if (type === "project") inc.projectCount = 1;
    // Update trendingScore heuristically
    const scoreInc = type === "hire" ? 5 : type === "project" ? 3 : 1;
    const updated = await CategoryModel.findOneAndUpdate(
      { slug },
      { $inc: { ...inc, trendingScore: scoreInc } },
      { new: true }
    ).lean();
    if (!updated) return res.status(404).json({ error: "Not found" });
    return res.json({ ok: true, category: updated });
  }

  const idx = MEMORY_CATEGORIES.findIndex((c) => c.slug === slug);
  if (idx === -1) return res.status(404).json({ error: "Not found" });
  if (type === "view") MEMORY_CATEGORIES[idx].viewCount++;
  if (type === "hire") MEMORY_CATEGORIES[idx].hireCount++;
  if (type === "project") MEMORY_CATEGORIES[idx].projectCount++;
  return res.json({ ok: true, category: MEMORY_CATEGORIES[idx] });
};
