import type { RequestHandler } from "express";
import multer from "multer";
import path from "path";
import { z } from "zod";
import { ProjectModel } from "../db";

const uploadDir = path.join(process.cwd(), "uploads");
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`),
});

export const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

export const ProjectSchema = z.object({
  title: z.string().min(4).max(120),
  description: z.string().min(20).max(5000),
  skills: z.array(z.string().min(1)).max(50),
  budget: z.coerce.number().positive().max(10_000_000),
  deadline: z.coerce.date(),
});

export type ProjectInput = z.infer<typeof ProjectSchema>;

// In-memory store fallback
const memoryProjects: any[] = [];

export const postProject: RequestHandler = async (req, res) => {
  try {
    const parsed = ProjectSchema.safeParse(JSON.parse(req.body.payload));
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.flatten() });
    }

    const files = (req as any).files as Array<{ originalname: string; path: string; size: number; mimetype: string }> | undefined;
    const attachments = files?.map((f) => ({
      filename: f.originalname,
      path: f.path,
      size: f.size,
      mimetype: f.mimetype,
    })) ?? [];

    const record = { ...parsed.data, attachments };

    if (ProjectModel.db?.readyState === 1) {
      const created = await ProjectModel.create(record);
      return res.json({ ok: true, project: created });
    }

    // Memory fallback
    const id = String(Date.now());
    const created = { id, ...record };
    memoryProjects.push(created);
    return res.json({ ok: true, project: created });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: "Failed to create project" });
  }
};

export const listProjects: RequestHandler = async (_req, res) => {
  try {
    if (ProjectModel.db?.readyState === 1) {
      const projects = await ProjectModel.find().sort({ createdAt: -1 }).lean();
      return res.json({ projects });
    }
    return res.json({ projects: memoryProjects.slice().reverse() });
  } catch (e) {
    return res.status(500).json({ error: "Failed to list projects" });
  }
};
