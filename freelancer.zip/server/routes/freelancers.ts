import type { RequestHandler } from "express";
import { z } from "zod";
import { FreelancerModel, isMongoReady } from "../schemas/freelancer";

// In-memory fallback dataset
const MEMORY_FREELANCERS: Array<{
  id: string;
  name: string;
  title: string;
  location: string;
  skills: string[];
  rating: number;
  bio: string;
  isAvailable: boolean;
  hourlyRate: number;
}> = [
  { id: "f1", name: "Alex Carter", title: "Senior React/Next.js Engineer", location: "Remote • US", skills: ["Next.js", "TypeScript", "Tailwind", "Stripe"], rating: 4.9, bio: "Built SaaS dashboards and marketplaces serving 100k+ users.", isAvailable: true, hourlyRate: 120 },
  { id: "f2", name: "Priya N.", title: "iOS Developer (SwiftUI)", location: "Hybrid • Toronto", skills: ["Swift", "SwiftUI", "Combine", "Firebase"], rating: 4.7, bio: "Delivered 12+ polished iOS apps end-to-end.", isAvailable: true, hourlyRate: 95 },
  { id: "f3", name: "Mateo R.", title: "Data Scientist / MLOps", location: "Remote • EU", skills: ["Python", "Pandas", "TensorFlow", "Airflow"], rating: 4.8, bio: "Time-series and recommender systems at scale.", isAvailable: false, hourlyRate: 110 },
  { id: "f4", name: "Hannah Lee", title: "Full-stack Engineer (Node/React)", location: "Remote • UK", skills: ["Node.js", "React", "PostgreSQL", "AWS"], rating: 4.6, bio: "Built multi-tenant SaaS and internal tools.", isAvailable: true, hourlyRate: 100 },
  { id: "f5", name: "Chen Wang", title: "Backend Engineer (Go)", location: "Remote • SG", skills: ["Go", "gRPC", "Kubernetes", "Redis"], rating: 4.5, bio: "Low-latency APIs and microservices.", isAvailable: true, hourlyRate: 130 },
  { id: "f6", name: "Sara Ahmed", title: "Product Designer (UX/UI)", location: "Cairo, EG", skills: ["Figma", "Design Systems", "Prototyping", "UX Research"], rating: 4.8, bio: "Accessible, data-informed product design.", isAvailable: false, hourlyRate: 80 },
  { id: "f7", name: "Diego Martinez", title: "Android Engineer (Kotlin)", location: "Remote • MX", skills: ["Kotlin", "Compose", "CI/CD", "MVVM"], rating: 4.4, bio: "Fintech apps with millions of installs.", isAvailable: true, hourlyRate: 90 },
  { id: "f8", name: "Emily Johnson", title: "Data Engineer", location: "NYC, USA", skills: ["Spark", "Airflow", "DBT", "Snowflake"], rating: 4.3, bio: "Batch/stream pipelines and BI.", isAvailable: true, hourlyRate: 140 },
  { id: "f9", name: "Omar Farouk", title: "DevOps/SRE", location: "Remote • DE", skills: ["Terraform", "AWS", "Prometheus", "Grafana"], rating: 4.7, bio: "Scalable infra and observability.", isAvailable: false, hourlyRate: 125 },
  { id: "f10", name: "Yuki Tanaka", title: "Frontend Engineer (Vue/React)", location: "Tokyo, JP", skills: ["Vue", "React", "TypeScript", "Vite"], rating: 4.6, bio: "Animations and performance.", isAvailable: true, hourlyRate: 85 },
];

const QuerySchema = z.object({
  q: z.string().trim().optional().default(""),
  skills: z.string().optional(), // comma separated
  location: z.string().trim().optional(),
  minRating: z.coerce.number().min(0).max(5).optional().default(0),
  available: z.coerce.boolean().optional(),
  sort: z.enum(["rating_desc", "rating_asc", "rate_desc", "rate_asc", "newest"]).optional().default("rating_desc"),
  page: z.coerce.number().min(1).optional().default(1),
  limit: z.coerce.number().min(1).max(100).optional().default(12),
});

export const searchFreelancers: RequestHandler = async (req, res) => {
  const parsed = QuerySchema.safeParse(req.query);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.flatten() });
  }
  const { q, skills, location, minRating, available, sort, page, limit } = parsed.data;
  const skillList = (skills || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  if (isMongoReady()) {
    // Mongo-backed search
    const filter: any = {};
    if (q) filter.$text = { $search: q };
    if (location) filter.location = { $regex: location, $options: "i" };
    if (minRating) filter.rating = { $gte: minRating };
    if (typeof available === "boolean") filter.isAvailable = available;
    if (skillList.length) filter.skills = { $all: skillList };

    const sortMap: Record<string, any> = {
      rating_desc: { rating: -1 },
      rating_asc: { rating: 1 },
      rate_desc: { hourlyRate: -1 },
      rate_asc: { hourlyRate: 1 },
      newest: { createdAt: -1 },
    };

    const cursor = FreelancerModel.find(filter).sort(sortMap[sort]).skip((page - 1) * limit).limit(limit).lean();
    const [items, total] = await Promise.all([
      cursor,
      FreelancerModel.countDocuments(filter),
    ]);

    return res.json({ items, total, page, pageSize: limit });
  }

  // In-memory fallback
  let items = MEMORY_FREELANCERS.slice();
  if (q) {
    const ql = q.toLowerCase();
    items = items.filter((f) =>
      (
        f.name + " " + f.title + " " + f.location + " " + f.skills.join(" ") + " " + f.bio
      ).toLowerCase().includes(ql)
    );
  }
  if (location) {
    const ll = location.toLowerCase();
    items = items.filter((f) => f.location.toLowerCase().includes(ll));
  }
  if (minRating) items = items.filter((f) => f.rating >= minRating);
  if (typeof available === "boolean") items = items.filter((f) => f.isAvailable === available);
  if (skillList.length) items = items.filter((f) => skillList.every((s) => f.skills.includes(s)));

  const sorters: Record<string, (a: any, b: any) => number> = {
    rating_desc: (a, b) => b.rating - a.rating,
    rating_asc: (a, b) => a.rating - b.rating,
    rate_desc: (a, b) => b.hourlyRate - a.hourlyRate,
    rate_asc: (a, b) => a.hourlyRate - b.hourlyRate,
    newest: (a, b) => (a.id < b.id ? 1 : -1),
  };
  items.sort(sorters[sort]);

  const total = items.length;
  const start = (page - 1) * limit;
  const paged = items.slice(start, start + limit);
  return res.json({ items: paged, total, page, pageSize: limit });
};
