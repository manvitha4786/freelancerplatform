import mongoose from "mongoose";

const FreelancerSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, index: true },
    title: { type: String, required: true, index: true },
    location: { type: String, default: "" },
    skills: { type: [String], default: [], index: true },
    rating: { type: Number, default: 0, index: true }, // 0-5
    bio: { type: String, default: "" },
    isAvailable: { type: Boolean, default: true, index: true },
    hourlyRate: { type: Number, default: 0, index: true },
  },
  { timestamps: true }
);

// Text index for search on name/title/bio
FreelancerSchema.index({ name: "text", title: "text", bio: "text" });

export const FreelancerModel = ((): mongoose.Model<any> => {
  try {
    return mongoose.model("Freelancer");
  } catch {
    return mongoose.model("Freelancer", FreelancerSchema);
  }
})();

export function isMongoReady() {
  try {
    return FreelancerModel.db?.readyState === 1;
  } catch {
    return false;
  }
}
