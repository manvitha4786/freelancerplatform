import mongoose from "mongoose";

const CategorySchema = new mongoose.Schema(
  {
    slug: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true, index: true },
    description: { type: String, default: "" },
    icon: { type: String, default: "" },
    colorFrom: { type: String, default: "#6366f1" },
    colorTo: { type: String, default: "#a855f7" },
    projectCount: { type: Number, default: 0, index: true },
    hireCount: { type: Number, default: 0, index: true },
    viewCount: { type: Number, default: 0, index: true },
    trendingScore: { type: Number, default: 0, index: true },
  },
  { timestamps: true }
);

CategorySchema.index({ name: "text", description: "text" });

export const CategoryModel = ((): mongoose.Model<any> => {
  try {
    return mongoose.model("Category");
  } catch {
    return mongoose.model("Category", CategorySchema);
  }
})();

export function isCategoryMongoReady() {
  try {
    return CategoryModel.db?.readyState === 1;
  } catch {
    return false;
  }
}
