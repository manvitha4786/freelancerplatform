import mongoose from "mongoose";

let isConnected = false;

export async function connectMongo(uri?: string) {
  if (isConnected) return mongoose.connection;
  const mongoUri = uri || process.env.MONGODB_URI;
  if (!mongoUri) return null; // Optional; fallbacks to in-memory stores
  await mongoose.connect(mongoUri, {
    serverSelectionTimeoutMS: 5000,
  });
  isConnected = true;
  return mongoose.connection;
}

// Project schema (used when Mongo is available)
const AttachmentSchema = new mongoose.Schema(
  {
    filename: String,
    path: String,
    size: Number,
    mimetype: String,
  },
  { _id: false },
);

const ProjectSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },
    skills: { type: [String], default: [] },
    budget: { type: Number, required: true },
    deadline: { type: Date, required: true },
    attachments: { type: [AttachmentSchema], default: [] },
    createdAt: { type: Date, default: Date.now },
  },
  { timestamps: true },
);

export const ProjectModel = ((): mongoose.Model<any> | null => {
  try {
    return mongoose.model("Project");
  } catch {
    return mongoose.model("Project", ProjectSchema);
  }
})();
