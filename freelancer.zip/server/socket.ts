import { Server } from "socket.io";

export type ChatMessage = {
  id: string;
  roomId: string;
  senderId: string;
  body: string;
  ts: number;
  readBy: string[];
};

const rooms = new Map<string, ChatMessage[]>();

export function initSockets(io: Server) {
  io.on("connection", (socket) => {
    const userId = (socket.handshake.auth?.userId as string) || `user_${socket.id.slice(0, 6)}`;

    socket.on("room:join", (roomId: string) => {
      socket.join(roomId);
      io.to(socket.id).emit("room:history", rooms.get(roomId) || []);
    });

    socket.on("message:send", ({ roomId, body }: { roomId: string; body: string }) => {
      const msg: ChatMessage = {
        id: `${Date.now()}_${Math.random().toString(36).slice(2)}`,
        roomId,
        senderId: userId,
        body,
        ts: Date.now(),
        readBy: [userId],
      };
      const list = rooms.get(roomId) || [];
      list.push(msg);
      rooms.set(roomId, list);
      io.to(roomId).emit("message:new", msg);
    });

    socket.on("message:read", ({ roomId, messageId }: { roomId: string; messageId: string }) => {
      const list = rooms.get(roomId) || [];
      const msg = list.find((m) => m.id === messageId);
      if (msg && !msg.readBy.includes(userId)) msg.readBy.push(userId);
      io.to(roomId).emit("message:read", { messageId, userId });
    });

    socket.on("disconnect", () => {});
  });
}
