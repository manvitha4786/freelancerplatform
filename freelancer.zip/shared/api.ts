/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

export interface AttachmentMeta {
  filename: string;
  path: string;
  size: number;
  mimetype: string;
}

export interface ProjectPayload {
  title: string;
  description: string;
  skills: string[];
  budget: number;
  deadline: string; // ISO
}

export interface ProjectResponse {
  ok: boolean;
  project: any;
}

export interface ChatMessage {
  id: string;
  roomId: string;
  senderId: string;
  body: string;
  ts: number;
  readBy: string[];
}

export interface Freelancer {
  _id?: string;
  id?: string;
  name: string;
  title: string;
  location: string;
  skills: string[];
  rating: number;
  bio: string;
  isAvailable: boolean;
  hourlyRate: number;
}

export interface FreelancerSearchQuery {
  q?: string;
  skills?: string; // comma separated
  location?: string;
  minRating?: number;
  available?: boolean;
  sort?: "rating_desc" | "rating_asc" | "rate_desc" | "rate_asc" | "newest";
  page?: number;
  limit?: number;
}

export interface PaginatedResult<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export interface Category {
  slug: string;
  name: string;
  description: string;
  icon: string;
  colorFrom: string;
  colorTo: string;
  projectCount: number;
  hireCount: number;
  viewCount: number;
  trendingScore?: number;
}

export interface CategoriesListResponse { items: Category[] }
