import { Shield, MessagesSquare, HandCoins, Workflow, Filter, Star, Users } from "lucide-react";

const features = [
  {
    icon: Shield,
    title: "Secure Payments",
    desc: "Milestone-based escrow with dispute handling and clear release controls.",
  },
  {
    icon: MessagesSquare,
    title: "Messaging & Files",
    desc: "Real-time chat with file sharing, read receipts, and typing indicators.",
  },
  {
    icon: Workflow,
    title: "Workspaces",
    desc: "Collaborative spaces with tasks, threads, and versioned attachments.",
  },
  {
    icon: HandCoins,
    title: "Bidding System",
    desc: "Post projects, compare proposals, negotiate, and hire with confidence.",
  },
  {
    icon: Filter,
    title: "Advanced Search",
    desc: "Skill, rate, timezone, availability, and verified badge filters.",
  },
  {
    icon: Star,
    title: "Endorsements",
    desc: "Skills endorsed by past clients to highlight proven expertise.",
  },
];

export function Features() {
  return (
    <section className="py-16 md:py-20">
      <div className="container">
        <div className="max-w-2xl">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight">Everything you need to collaborate</h2>
          <p className="mt-3 text-foreground/70">A modern, end-to-end platform built on MERN for reliability and speed.</p>
        </div>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="group rounded-xl border border-border bg-card p-6 transition hover:shadow-lg">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-gradient-to-br from-primary to-purple-600 text-primary-foreground">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-semibold text-lg">{title}</h3>
              <p className="mt-2 text-sm text-foreground/70">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
