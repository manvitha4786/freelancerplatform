import { useEffect, useState } from "react";
import type { Category, CategoriesListResponse } from "@shared/api";

export function Categories() {
  const [items, setItems] = useState<Category[]>([]);

  useEffect(() => {
    (async () => {
      try {
        const resp = await fetch("/api/categories?sort=trending&limit=6");
        if (!resp.ok) return;
        const json = (await resp.json()) as CategoriesListResponse;
        setItems(json.items);
      } catch {
        // ignore, keep empty
      }
    })();
  }, []);

  return (
    <section className="py-16 md:py-20">
      <div className="container">
        <div className="flex items-end justify-between gap-4 flex-wrap">
          <div>
            <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight">Popular categories</h2>
            <p className="text-sm text-foreground/70 mt-2">Browse top talent across the most in-demand skills.</p>
          </div>
          <a href="/categories" className="text-sm font-medium text-primary hover:underline">Explore all</a>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((cat) => (
            <a
              key={cat.slug}
              href={`/browse?mode=freelancers&skills=${encodeURIComponent(cat.name)}`}
              className={`relative overflow-hidden rounded-xl border border-border bg-card p-6 transition hover:shadow-lg`}
            >
              <div className={`absolute -right-10 -top-10 h-28 w-28 rounded-full bg-gradient-to-br opacity-20`} style={{ backgroundImage: `linear-gradient(to bottom right, ${cat.colorFrom}, ${cat.colorTo})` }} />
              <div className="relative font-semibold">{cat.name}</div>
              <div className="relative mt-2 text-sm text-foreground/70">{cat.projectCount.toLocaleString()} projects • {cat.hireCount.toLocaleString()} hires</div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
