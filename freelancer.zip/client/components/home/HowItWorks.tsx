import { ClipboardList, FileSignature, ArrowRightLeft, Trophy } from "lucide-react";

const steps = [
  { icon: ClipboardList, title: "Post a project", desc: "Describe the scope, budget, and timeline." },
  { icon: ArrowRightLeft, title: "Receive bids", desc: "Compare proposals and chat to align on scope." },
  { icon: FileSignature, title: "Set milestones", desc: "Create clear deliverables with escrow payments." },
  { icon: Trophy, title: "Deliver & pay", desc: "Review work, release payments, and rate experience." },
];

export function HowItWorks() {
  return (
    <section className="py-16 md:py-20">
      <div className="container">
        <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight">How it works</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-4">
          {steps.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="rounded-xl border border-border bg-card p-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-accent text-foreground">
                <Icon className="h-5 w-5" />
              </div>
              <div className="mt-3 font-semibold">{title}</div>
              <div className="text-sm text-foreground/70 mt-1">{desc}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
