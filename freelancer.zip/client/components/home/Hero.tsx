import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Search, ShieldCheck, Zap, Users } from "lucide-react";

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(1000px_500px_at_50%_-10%,hsl(var(--primary)/0.15),transparent),linear-gradient(to_bottom_right,hsl(var(--background)),hsl(var(--background)))]" />
      <div className="container py-20 md:py-28">
        <div className="grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-background/60 px-3 py-1 text-xs mb-5">Secure • Escrow • Workspaces</div>
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight leading-tight">
              Build together.
              <br />
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-600">Hire faster.</span>
            </h1>
            <p className="mt-5 text-lg text-foreground/70 max-w-xl">
              A professional platform to post projects, receive bids, collaborate in secure workspaces, and pay with confidence.
            </p>

            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <Link to="/post"><Button size="lg" className="bg-gradient-to-r from-primary to-purple-600">Post a Project</Button></Link>
              <Link to="/browse"><Button size="lg" variant="outline">Browse Freelancers</Button></Link>
            </div>

            <div className="mt-8 grid grid-cols-3 gap-4 text-sm text-foreground/70">
              <div className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-emerald-500" /> Escrow payments</div>
              <div className="flex items-center gap-2"><Zap className="h-4 w-4 text-amber-500" /> Real-time updates</div>
              <div className="flex items-center gap-2"><Users className="h-4 w-4 text-blue-500" /> Verified talent</div>
            </div>
          </div>

          <div className="relative">
            <div className="rounded-2xl border border-border bg-card p-4 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.25)]">
              <div className="rounded-xl bg-gradient-to-br from-slate-50 to-white dark:from-slate-900/30 dark:to-slate-900/10 border border-border p-4">
                <div className="text-sm text-foreground/70 mb-2">Find top talent</div>
                <div className="flex items-center gap-2 rounded-lg border border-input bg-background px-3 py-2">
                  <Search className="h-4 w-4 text-foreground/60" />
                  <input className="flex-1 bg-transparent outline-none placeholder:text-foreground/50" placeholder="Try: Next.js, Mobile App, Data Science" />
                  <Button size="sm" className="bg-gradient-to-r from-primary to-purple-600">Search</Button>
                </div>
                <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                  {[
                    "Web Development",
                    "Mobile Apps",
                    "AI & ML",
                    "Design",
                    "Data & Analytics",
                    "Marketing",
                  ].map((tag) => (
                    <span key={tag} className="inline-flex items-center justify-center rounded-md border border-border px-2 py-1 text-foreground/70 hover:text-foreground hover:bg-accent cursor-pointer">{tag}</span>
                  ))}
                </div>
              </div>
              <div className="mt-4 rounded-xl border border-border bg-background p-4 grid gap-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-semibold">E-commerce Website Redesign</div>
                    <div className="text-xs text-foreground/70">Fixed • $2,500 • 3 Milestones</div>
                  </div>
                  <span className="text-xs rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-2 py-1 border border-emerald-500/20">Active</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-foreground/70">
                  <span className="rounded-md bg-accent px-2 py-1">Next.js</span>
                  <span className="rounded-md bg-accent px-2 py-1">TailwindCSS</span>
                  <span className="rounded-md bg-accent px-2 py-1">Stripe</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
