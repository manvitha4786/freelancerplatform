import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export function CTA() {
  return (
    <section className="py-16">
      <div className="container">
        <div className="rounded-2xl border border-border bg-gradient-to-br from-background to-accent/30 p-8 md:p-12 text-center">
          <h3 className="text-2xl md:text-3xl font-extrabold tracking-tight">Ready to start collaborating?</h3>
          <p className="mt-3 text-foreground/70 max-w-2xl mx-auto">Post your first project or browse our curated network of verified freelancers to bring your ideas to life.</p>
          <div className="mt-6 flex items-center justify-center gap-3">
            <Link to="/post"><Button size="lg" className="bg-gradient-to-r from-primary to-purple-600">Post a Project</Button></Link>
            <Link to="/browse"><Button size="lg" variant="outline">Browse Talent</Button></Link>
          </div>
        </div>
      </div>
    </section>
  );
}
