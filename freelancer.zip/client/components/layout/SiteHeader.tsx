import { Link, NavLink } from "react-router-dom";
import { useState } from "react";
import { Menu, X, Rocket, Bell, MessageSquareText, BriefcaseBusiness } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navItems = [
  { to: "/browse", label: "Browse" },
  { to: "/categories", label: "Categories" },
  { to: "/post", label: "Post a Project" },
  { to: "/messages", label: "Messages" },
  { to: "/dashboard", label: "Dashboard" },
  { to: "/admin", label: "Admin" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full bg-background/70 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/" className="flex items-center gap-2 font-extrabold text-lg tracking-tight">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-primary to-purple-600 text-primary-foreground shadow-sm"><Rocket className="h-4 w-4" /></span>
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-600">Collabify</span>
          </Link>
          <nav className="hidden lg:flex items-center gap-1 ml-6">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  cn(
                    "px-3 py-2 rounded-md text-sm font-medium text-foreground/80 hover:text-foreground hover:bg-accent",
                    isActive && "text-foreground bg-accent"
                  )
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>
        </div>

        <div className="hidden lg:flex items-center gap-2">
          <NavLink to="/login"><Button variant="ghost">Log in</Button></NavLink>
          <NavLink to="/register"><Button className="bg-gradient-to-r from-primary to-purple-600">Sign up</Button></NavLink>
          <NavLink to="/messages" className="ml-2 relative">
            <Button variant="ghost" size="icon"><MessageSquareText /></Button>
            <span className="absolute -right-1 -top-1 h-4 w-4 rounded-full bg-emerald-500 text-[10px] text-white grid place-items-center">3</span>
          </NavLink>
          <NavLink to="/notifications" className="relative">
            <Button variant="ghost" size="icon"><Bell /></Button>
          </NavLink>
        </div>

        <button className="lg:hidden inline-flex items-center justify-center p-2 rounded-md hover:bg-accent" onClick={() => setOpen((v) => !v)} aria-label="Toggle menu">
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="lg:hidden border-t border-border bg-background">
          <div className="container py-3 grid gap-2">
            {navItems.map((item) => (
              <NavLink key={item.to} to={item.to} onClick={() => setOpen(false)} className={({ isActive }) => cn("px-2 py-2 rounded-md text-sm font-medium hover:bg-accent", isActive && "bg-accent")}>{item.label}</NavLink>
            ))}
            <div className="flex gap-2 pt-2">
              <NavLink to="/login" onClick={() => setOpen(false)} className="flex-1"><Button variant="ghost" className="w-full">Log in</Button></NavLink>
              <NavLink to="/register" onClick={() => setOpen(false)} className="flex-1"><Button className="w-full bg-gradient-to-r from-primary to-purple-600">Sign up</Button></NavLink>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Link to="/messages" onClick={() => setOpen(false)} className="flex items-center gap-2 px-2 py-2 rounded-md hover:bg-accent"><MessageSquareText className="h-4 w-4" /> Messages</Link>
              <Link to="/dashboard" onClick={() => setOpen(false)} className="flex items-center gap-2 px-2 py-2 rounded-md hover:bg-accent"><BriefcaseBusiness className="h-4 w-4" /> Dashboard</Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
