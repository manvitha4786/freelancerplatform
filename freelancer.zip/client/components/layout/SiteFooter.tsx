import { Link } from "react-router-dom";

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-background/60">
      <div className="container py-12 grid gap-8 md:grid-cols-4">
        <div>
          <div className="font-extrabold text-xl bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-600">Collabify</div>
          <p className="text-sm text-foreground/70 mt-3 max-w-xs">A modern freelancer collaboration platform for building world-class products together.</p>
        </div>
        <div>
          <div className="font-semibold mb-3">Product</div>
          <ul className="space-y-2 text-sm text-foreground/70">
            <li><Link to="/browse" className="hover:text-foreground">Browse</Link></li>
            <li><Link to="/post" className="hover:text-foreground">Post a Project</Link></li>
            <li><Link to="/workspace" className="hover:text-foreground">Workspaces</Link></li>
            <li><Link to="/messages" className="hover:text-foreground">Messages</Link></li>
          </ul>
        </div>
        <div>
          <div className="font-semibold mb-3">Company</div>
          <ul className="space-y-2 text-sm text-foreground/70">
            <li><Link to="/about" className="hover:text-foreground">About</Link></li>
            <li><Link to="/careers" className="hover:text-foreground">Careers</Link></li>
            <li><Link to="/blog" className="hover:text-foreground">Blog</Link></li>
            <li><Link to="/help" className="hover:text-foreground">Help Center</Link></li>
          </ul>
        </div>
        <div>
          <div className="font-semibold mb-3">Legal</div>
          <ul className="space-y-2 text-sm text-foreground/70">
            <li><Link to="/terms" className="hover:text-foreground">Terms</Link></li>
            <li><Link to="/privacy" className="hover:text-foreground">Privacy</Link></li>
            <li><Link to="/cookies" className="hover:text-foreground">Cookies</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="container py-6 text-xs text-foreground/60 flex flex-col md:flex-row items-center justify-between gap-3">
          <p>© {new Date().getFullYear()} Collabify, Inc. All rights reserved.</p>
          <p>Made with care for a seamless, secure experience.</p>
        </div>
      </div>
    </footer>
  );
}
