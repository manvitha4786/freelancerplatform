import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export function PlaceholderPage({ title, description }: { title: string; description?: string }) {
  return (
    <div className="min-h-[60vh] grid place-items-center">
      <div className="text-center max-w-2xl">
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">{title}</h1>
        {description ? (
          <p className="mt-3 text-foreground/70">{description}</p>
        ) : null}
        <div className="mt-6 flex items-center justify-center gap-3">
          <Link to="/"><Button variant="outline">Go Home</Button></Link>
          <Link to="/post"><Button className="bg-gradient-to-r from-primary to-purple-600">Post a Project</Button></Link>
        </div>
      </div>
    </div>
  );
}
