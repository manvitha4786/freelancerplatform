import { ReactNode } from "react";
import { Rocket, Laptop, Briefcase, Handshake, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";

export function AuthLayout({
  children,
  title,
  subtitle,
  footer,
}: {
  children: ReactNode;
  title: string;
  subtitle?: string;
  footer?: ReactNode;
}) {
  return (
    <main className="min-h-[80vh] container py-10 grid lg:grid-cols-2 gap-10 items-stretch">
      <section className="hidden lg:flex relative rounded-2xl border border-border overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-accent/10 to-transparent" />
        <div className="relative p-10 flex flex-col justify-between w-full">
          <div>
            <Link to="/" className="inline-flex items-center gap-2 font-extrabold text-lg">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-primary to-purple-600 text-white"><Rocket className="h-4 w-4" /></span>
              Collabify
            </Link>
            <h2 className="mt-8 text-4xl font-extrabold tracking-tight">Create your freelance future</h2>
            <p className="mt-3 text-foreground/70 max-w-md">Join a trusted community of clients and freelancers collaborating in secure workspaces with milestone payments.</p>
          </div>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div className="flex items-center gap-2 rounded-xl border border-border bg-card/60 p-3">
              <Laptop className="h-4 w-4 text-blue-500" /> Remote-first
            </div>
            <div className="flex items-center gap-2 rounded-xl border border-border bg-card/60 p-3">
              <Briefcase className="h-4 w-4 text-emerald-500" /> Verified jobs
            </div>
            <div className="flex items-center gap-2 rounded-xl border border-border bg-card/60 p-3">
              <Handshake className="h-4 w-4 text-amber-500" /> Trusted escrow
            </div>
          </div>
        </div>
        <Sparkles className="absolute right-6 top-6 h-6 w-6 text-primary/50" />
      </section>

      <section className="rounded-2xl border border-border p-6 md:p-10 bg-card max-w-xl w-full mx-auto">
        <h1 className="text-3xl font-extrabold tracking-tight">{title}</h1>
        {subtitle ? <p className="text-foreground/70 mt-2">{subtitle}</p> : null}
        <div className="mt-8">{children}</div>
        {footer ? <div className="mt-6 text-sm text-foreground/70">{footer}</div> : null}
      </section>
    </main>
  );
}
