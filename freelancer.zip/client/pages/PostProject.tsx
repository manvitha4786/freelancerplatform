import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import type { ProjectPayload, ProjectResponse } from "@shared/api";

const schema = z.object({
  title: z.string().min(4, "Title is required").max(120),
  description: z.string().min(20, "Describe your project").max(5000),
  skills: z.string().min(1, "Add at least one skill"),
  budget: z.coerce.number().positive("Budget must be positive"),
  deadline: z.string().min(1, "Pick a deadline"),
  files: z.any().optional(),
});

type FormValues = z.infer<typeof schema>;

export default function PostProject() {
  const [submitting, setSubmitting] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const onSubmit = async (values: FormValues) => {
    setSubmitting(true);
    try {
      const payload: ProjectPayload = {
        title: values.title,
        description: values.description,
        skills: values.skills.split(",").map((s) => s.trim()).filter(Boolean),
        budget: Number(values.budget),
        deadline: new Date(values.deadline).toISOString(),
      };

      const fd = new FormData();
      fd.append("payload", JSON.stringify(payload));
      const files = (values as any).files as FileList | undefined;
      if (files) Array.from(files).forEach((f) => fd.append("files", f));

      const res = await fetch("/api/projects", { method: "POST", body: fd });
      if (!res.ok) throw new Error("Failed to submit");
      const data = (await res.json()) as ProjectResponse;
      toast.success("Project posted successfully");
      reset();
      // Optionally navigate or show summary
      console.log("Created project", data.project);
    } catch (e: any) {
      toast.error(e?.message || "Submission failed");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="container py-10">
      <div className="max-w-3xl">
        <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Post a Project</h1>
        <p className="text-foreground/70 mt-2">Create a detailed brief with skills, budget, milestones, and files to attract the right talent.</p>

        <form onSubmit={handleSubmit(onSubmit)} className="mt-8 grid gap-6">
          <div>
            <label className="block text-sm font-medium">Project title</label>
            <input {...register("title")} className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" placeholder="e.g. React Native Fintech App" />
            {errors.title && <p className="mt-1 text-sm text-red-600">{errors.title.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium">Description</label>
            <textarea {...register("description")} rows={6} className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" placeholder="Outline scope, deliverables, and expectations" />
            {errors.description && <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium">Required skills</label>
            <input {...register("skills")} className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" placeholder="Comma-separated, e.g. Next.js, Tailwind, Stripe" />
            <p className="mt-1 text-xs text-foreground/60">Use commas to separate skills.</p>
            {errors.skills && <p className="mt-1 text-sm text-red-600">{errors.skills.message}</p>}
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium">Budget (USD)</label>
              <input type="number" step="1" min="1" {...register("budget")} className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" placeholder="2500" />
              {errors.budget && <p className="mt-1 text-sm text-red-600">{errors.budget.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium">Deadline</label>
              <input type="date" {...register("deadline")} className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" />
              {errors.deadline && <p className="mt-1 text-sm text-red-600">{errors.deadline.message}</p>}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium">File attachments</label>
            <input type="file" multiple {...register("files")} className="mt-2 block w-full text-sm" />
            <p className="mt-1 text-xs text-foreground/60">Up to 8 files, max 10MB each.</p>
          </div>

          <div className="flex items-center gap-3">
            <Button type="submit" disabled={submitting} className="bg-gradient-to-r from-primary to-purple-600">
              {submitting ? "Submitting..." : "Post project"}
            </Button>
            <Button type="button" variant="outline" onClick={() => reset()}>Reset</Button>
          </div>
        </form>
      </div>
    </main>
  );
}
