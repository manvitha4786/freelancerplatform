import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { io, Socket } from "socket.io-client";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Activity, AlertTriangle, BarChart3, ShieldCheck, Users, BriefcaseBusiness, Bell } from "lucide-react";

function useSocketFeed(roomId: string) {
  const [events, setEvents] = useState<Array<{ id: string; text: string; at: number }>>([]);
  const socketRef = useRef<Socket | null>(null);
  useEffect(() => {
    const s = io("", { path: "/socket.io", transports: ["websocket"] });
    socketRef.current = s;
    s.emit("room:join", roomId);
    const onNew = (msg: any) => setEvents((e) => [{ id: msg.id, text: msg.body, at: msg.ts }, ...e].slice(0, 25));
    s.on("message:new", onNew);
    return () => {
      s.off("message:new", onNew);
      s.disconnect();
      socketRef.current = null;
    };
  }, [roomId]);
  return { events };
}

export default function Admin() {
  const stats = useMemo(
    () => [
      { label: "Users", value: 1287, icon: Users, color: "text-blue-600" },
      { label: "Active Projects", value: 76, icon: BriefcaseBusiness, color: "text-emerald-600" },
      { label: "Open Tickets", value: 8, icon: AlertTriangle, color: "text-amber-600" },
      { label: "System Health", value: "OK", icon: ShieldCheck, color: "text-purple-600" },
    ],
    [],
  );

  const progressData = Array.from({ length: 10 }).map((_, i) => ({
    w: `W${i + 1}`,
    value: Math.round(50 + Math.sin(i / 2) * 30 + (i * 7) % 20),
  }));

  const users = [
    { id: 1, name: "Alex Doe", role: "freelancer", status: "active", joined: "2024-06-12" },
    { id: 2, name: "Riley Stone", role: "client", status: "suspended", joined: "2024-07-03" },
    { id: 3, name: "Sam Lee", role: "freelancer", status: "active", joined: "2024-08-21" },
  ];

  const projects = [
    { id: 1, name: "E‑commerce Redesign", client: "Acme Co.", budget: "$25,000", status: "active", progress: 72 },
    { id: 2, name: "iOS Banking App", client: "FinX", budget: "$80,000", status: "in_review", progress: 46 },
    { id: 3, name: "Data Dashboard", client: "Insightly", budget: "$40,000", status: "completed", progress: 100 },
  ];

  const tickets = [
    { id: 701, subject: "Payment verification delay", requester: "Morgan", age: "2h" },
    { id: 702, subject: "Milestone dispute", requester: "Jamie", age: "5h" },
    { id: 703, subject: "Can't upload files", requester: "Taylor", age: "1d" },
  ];

  const { events } = useSocketFeed("general");

  return (
    <main className="container py-8">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Admin</h1>
          <p className="text-foreground/70 mt-1">Manage users, oversee projects, monitor health, and respond to tickets.</p>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/dashboard"><Button variant="outline"><BarChart3 className="h-4 w-4 mr-2"/>View Dashboard</Button></Link>
          <Link to="/messages"><Button className="bg-gradient-to-r from-primary to-purple-600"><Bell className="h-4 w-4 mr-2"/>Open Messages</Button></Link>
        </div>
      </div>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4 mt-6">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-border bg-card p-5">
            <div className="flex items-center justify-between">
              <div className="text-sm text-foreground/70">{s.label}</div>
              <s.icon className={`h-5 w-5 ${s.color}`} />
            </div>
            <div className="mt-2 text-2xl font-bold">{s.value}</div>
          </div>
        ))}
      </section>

      <section className="grid gap-6 lg:grid-cols-3 mt-6">
        <div className="rounded-xl border border-border bg-card p-5 lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-semibold">Platform Analytics</div>
              <div className="text-sm text-foreground/70">Active projects and throughput</div>
            </div>
            <Activity className="h-4 w-4 text-primary" />
          </div>
          <div className="h-56 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={progressData} margin={{ left: 0, right: 0, top: 10, bottom: 0 }}>
                <defs>
                  <linearGradient id="agrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--accent))" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="hsl(var(--accent))" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="w" stroke="hsl(var(--foreground))" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="hsl(var(--foreground))" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }} labelStyle={{ color: "hsl(var(--foreground))" }} />
                <Area type="monotone" dataKey="value" stroke="hsl(var(--accent))" fill="url(#agrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center justify-between"><div className="font-semibold">Realtime Notifications</div><Bell className="h-4 w-4 text-primary"/></div>
          <ul className="mt-3 space-y-3 text-sm max-h-56 overflow-auto">
            {events.length === 0 ? <li className="text-foreground/60">No new notifications</li> : null}
            {events.map((e) => (
              <li key={e.id} className="rounded-md border border-border p-3 bg-background">
                <div className="font-medium truncate">{e.text}</div>
                <div className="text-xs text-foreground/60">{new Date(e.at).toLocaleString()}</div>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="grid gap-6 xl:grid-cols-2 mt-6">
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="font-semibold">User Management</div>
          <div className="overflow-x-auto mt-3">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-foreground/70">
                  <th className="py-2 pr-4">Name</th>
                  <th className="py-2 pr-4">Role</th>
                  <th className="py-2 pr-4">Status</th>
                  <th className="py-2 pr-4">Joined</th>
                  <th className="py-2 pr-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-t border-border">
                    <td className="py-2 pr-4">{u.name}</td>
                    <td className="py-2 pr-4 capitalize">{u.role}</td>
                    <td className="py-2 pr-4">
                      <span className={`px-2 py-1 rounded-md text-xs ${u.status === "active" ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "bg-red-500/10 text-red-600 dark:text-red-400"}`}>{u.status}</span>
                    </td>
                    <td className="py-2 pr-4">{u.joined}</td>
                    <td className="py-2 pr-4 flex gap-2">
                      <Button variant="outline" size="sm">View</Button>
                      <Button variant="ghost" size="sm">{u.status === "active" ? "Suspend" : "Restore"}</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-5">
          <div className="font-semibold">Project Oversight</div>
          <div className="overflow-x-auto mt-3">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-foreground/70">
                  <th className="py-2 pr-4">Project</th>
                  <th className="py-2 pr-4">Client</th>
                  <th className="py-2 pr-4">Budget</th>
                  <th className="py-2 pr-4">Status</th>
                  <th className="py-2 pr-4">Milestones</th>
                </tr>
              </thead>
              <tbody>
                {projects.map((p) => (
                  <tr key={p.id} className="border-top border-border">
                    <td className="py-2 pr-4">{p.name}</td>
                    <td className="py-2 pr-4">{p.client}</td>
                    <td className="py-2 pr-4">{p.budget}</td>
                    <td className="py-2 pr-4 capitalize">
                      <span className={`px-2 py-1 rounded-md text-xs ${p.status === "completed" ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : p.status === "active" ? "bg-blue-500/10 text-blue-600 dark:text-blue-400" : "bg-amber-500/10 text-amber-600 dark:text-amber-400"}`}>{p.status.replace("_"," ")}</span>
                    </td>
                    <td className="py-2 pr-4">
                      <div className="h-2 rounded-full bg-accent">
                        <div className="h-2 rounded-full bg-gradient-to-r from-primary to-purple-600" style={{ width: `${p.progress}%` }} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-border bg-card p-5 mt-6">
        <div className="flex items-center justify-between"><div className="font-semibold">Support Tickets</div><Link to="/messages" className="text-sm text-primary hover:underline">Open inbox</Link></div>
        <ul className="mt-3 grid md:grid-cols-3 gap-3 text-sm">
          {tickets.map((t) => (
            <li key={t.id} className="rounded-md border border-border p-3 bg-background">
              <div className="font-medium truncate">#{t.id} — {t.subject}</div>
              <div className="text-xs text-foreground/60">From {t.requester} • {t.age} ago</div>
              <div className="mt-3 flex gap-2">
                <Button size="sm" variant="outline">View</Button>
                <Button size="sm" className="bg-gradient-to-r from-primary to-purple-600">Assign</Button>
              </div>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
