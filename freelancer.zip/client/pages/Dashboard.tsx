import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Bell, Briefcase, CheckCircle2, Files, MessageSquareText, Plus } from "lucide-react";

const progressData = Array.from({ length: 12 }).map((_, i) => ({
  month: new Date(2024, i, 1).toLocaleString(undefined, { month: "short" }),
  progress: Math.round(40 + Math.sin(i / 2) * 30 + (i * 3) % 20),
}));

export default function Dashboard() {
  const stats = useMemo(
    () => [
      { label: "Active Projects", value: 4, icon: Briefcase, color: "text-blue-600" },
      { label: "Tasks Due", value: 9, icon: CheckCircle2, color: "text-emerald-600" },
      { label: "Messages", value: 12, icon: MessageSquareText, color: "text-amber-600" },
      { label: "Files", value: 28, icon: Files, color: "text-purple-600" },
    ],
    [],
  );

  const notifications = [
    { id: 1, text: "Milestone approved on E‑commerce Redesign", time: "2h" },
    { id: 2, text: "New message from Alex (Mobile App)", time: "5h" },
    { id: 3, text: "Proposal received for Data Dashboard", time: "1d" },
    { id: 4, text: "Deadline in 2 days: Branding Kit", time: "2d" },
  ];

  const tasks = [
    { id: 1, text: "Implement payments integration", done: false },
    { id: 2, text: "Create onboarding walkthrough", done: true },
    { id: 3, text: "QA mobile responsiveness", done: false },
  ];

  const files = [
    { id: 1, name: "requirements.pdf", size: "1.2 MB" },
    { id: 2, name: "wireframes.fig", size: "3.8 MB" },
    { id: 3, name: "brand-kit.zip", size: "14.1 MB" },
  ];

  return (
    <main className="container py-8">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Dashboard</h1>
          <p className="text-foreground/70 mt-1">Manage projects, tasks, files, and conversations in one place.</p>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/post"><Button className="bg-gradient-to-r from-primary to-purple-600"><Plus className="mr-2 h-4 w-4"/>New Project</Button></Link>
          <Link to="/messages"><Button variant="outline"><MessageSquareText className="mr-2 h-4 w-4"/>Open Messages</Button></Link>
        </div>
      </div>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4 mt-6">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-border bg-card p-5">
            <div className={`flex items-center justify-between`}>
              <div className="text-sm text-foreground/70">{s.label}</div>
              <s.icon className={`h-5 w-5 ${s.color}`} />
            </div>
            <div className="mt-2 text-2xl font-bold">{s.value}</div>
          </div>
        ))}
      </section>

      <section className="grid gap-6 lg:grid-cols-3 mt-6">
        <div className="rounded-xl border border-border bg-card p-5 lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-semibold">Project Progress</div>
              <div className="text-sm text-foreground/70">Milestone completion over time</div>
            </div>
          </div>
          <div className="h-56 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={progressData} margin={{ left: 0, right: 0, top: 10, bottom: 0 }}>
                <defs>
                  <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" stroke="hsl(var(--foreground))" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="hsl(var(--foreground))" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }} labelStyle={{ color: "hsl(var(--foreground))" }} />
                <Area type="monotone" dataKey="progress" stroke="hsl(var(--primary))" fill="url(#grad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center justify-between"><div className="font-semibold">Notifications</div><Bell className="h-4 w-4 text-primary"/></div>
          <ul className="mt-3 space-y-3 text-sm">
            {notifications.map((n) => (
              <li key={n.id} className="flex items-start justify-between gap-3 rounded-md border border-border p-3 bg-background">
                <span>{n.text}</span>
                <span className="text-foreground/60 text-xs whitespace-nowrap">{n.time}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-3 mt-6">
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="font-semibold">Tasks</div>
          <ul className="mt-3 space-y-2 text-sm">
            {tasks.map((t) => (
              <li key={t.id} className="flex items-center gap-2 rounded-md border border-border p-2 bg-background">
                <input type="checkbox" defaultChecked={t.done} className="h-4 w-4" />
                <span className={t.done ? "line-through text-foreground/60" : ""}>{t.text}</span>
              </li>
            ))}
          </ul>
          <Link to="/workspace" className="inline-flex mt-4 text-sm text-primary hover:underline">Go to workspace</Link>
        </div>
        <div className="rounded-xl border border-border bg-card p-5 lg:col-span-2">
          <div className="flex items-center justify-between"><div className="font-semibold">Recent Files</div><Link to="/workspace" className="text-sm text-primary hover:underline">View all</Link></div>
          <ul className="mt-3 space-y-2 text-sm">
            {files.map((f) => (
              <li key={f.id} className="flex items-center justify-between rounded-md border border-border p-2 bg-background">
                <span className="truncate">{f.name}</span>
                <span className="text-foreground/60 text-xs">{f.size}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </main>
  );
}
