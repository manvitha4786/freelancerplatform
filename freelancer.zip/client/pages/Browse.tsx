import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Search, MapPin, Star, ChevronLeft, ChevronRight } from "lucide-react";
import type { Freelancer, PaginatedResult } from "@shared/api";

function Stars({ value }: { value: number }) {
  const full = Math.floor(value);
  const half = value - full >= 0.5;
  return (
    <div className="inline-flex items-center gap-0.5 text-amber-500">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={`h-4 w-4 ${i < full ? "fill-current" : half && i === full ? "fill-current opacity-50" : "opacity-30"}`} />
      ))}
      <span className="ml-1 text-xs text-foreground/70">{value.toFixed(1)}</span>
    </div>
  );
}

// Static client previews (kept local until clients API exists)
const CLIENTS = [
  { id: "c1", company: "Acme Co.", location: "NYC, USA", focus: ["E‑commerce", "Design"], rating: 4.6, about: "Growing DTC brand modernizing storefront and checkout." },
  { id: "c2", company: "FinX", location: "SF, USA", focus: ["Fintech", "Mobile"], rating: 4.8, about: "Building consumer banking experiences on iOS & Android." },
  { id: "c3", company: "Insightly", location: "Berlin, DE", focus: ["Analytics", "Data"], rating: 4.5, about: "Insights platform for SMBs—dashboards & reporting." },
];

export default function Browse() {
  const [mode, setMode] = useState<"freelancers" | "clients">("freelancers");
  const [q, setQ] = useState("");
  const [skills, setSkills] = useState("");
  const [location, setLocation] = useState("");
  const [minRating, setMinRating] = useState(4);
  const [available, setAvailable] = useState<boolean | undefined>(undefined);
  const [sort, setSort] = useState<"rating_desc" | "rating_asc" | "rate_desc" | "rate_asc" | "newest">("rating_desc");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(12);

  // Initialize from URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const m = params.get("mode");
    const qq = params.get("q");
    const sk = params.get("skills");
    const loc = params.get("location");
    const mr = params.get("minRating");
    const av = params.get("available");
    const so = params.get("sort");
    if (m === "freelancers" || m === "clients") setMode(m);
    if (qq) setQ(qq);
    if (sk) setSkills(sk);
    if (loc) setLocation(loc);
    if (mr) setMinRating(Number(mr));
    if (av === "true" || av === "false") setAvailable(av === "true");
    if (so && ["rating_desc","rating_asc","rate_desc","rate_asc","newest"].includes(so)) setSort(so as any);
  }, []);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<PaginatedResult<Freelancer>>({ items: [], total: 0, page: 1, pageSize: limit });

  // Debounce inputs
  const debounceKey = useMemo(() => [q, skills, location, minRating, available, sort, page, limit].join("|"), [q, skills, location, minRating, available, sort, page, limit]);
  useEffect(() => {
    if (mode !== "freelancers") return;
    const h = setTimeout(async () => {
      try {
        setLoading(true);
        setError(null);
        const params = new URLSearchParams();
        if (q) params.set("q", q);
        if (skills) params.set("skills", skills);
        if (location) params.set("location", location);
        if (minRating) params.set("minRating", String(minRating));
        if (typeof available === "boolean") params.set("available", String(available));
        if (sort) params.set("sort", sort);
        params.set("page", String(page));
        params.set("limit", String(limit));
        const resp = await fetch(`/api/freelancers?${params.toString()}`);
        if (!resp.ok) throw new Error(`Request failed: ${resp.status}`);
        const json = (await resp.json()) as PaginatedResult<Freelancer>;
        setData(json);
      } catch (e: any) {
        setError(e.message || "Failed to load freelancers");
      } finally {
        setLoading(false);
      }
    }, 300);
    return () => clearTimeout(h);
  }, [debounceKey, mode]);

  const totalPages = useMemo(() => Math.max(1, Math.ceil(data.total / data.pageSize)), [data.total, data.pageSize]);

  // Reset page when filters change (except page itself)
  useEffect(() => {
    setPage(1);
  }, [q, skills, location, minRating, available, sort, limit, mode]);

  const skillList = useMemo(() => skills.split(",").map((s) => s.trim()).filter(Boolean), [skills]);

  return (
    <main className="container py-8">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Explore {mode === "freelancers" ? "Freelancers" : "Clients"}</h1>
          <p className="text-foreground/70 mt-1">Find the right {mode === "freelancers" ? "expert" : "partner"} by skills, location, rating, and more.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant={mode === "freelancers" ? "default" : "outline"} onClick={() => setMode("freelancers")} className={mode === "freelancers" ? "bg-gradient-to-r from-primary to-purple-600" : ""}>Freelancers</Button>
          <Button variant={mode === "clients" ? "default" : "outline"} onClick={() => setMode("clients")} className={mode === "clients" ? "bg-gradient-to-r from-primary to-purple-600" : ""}>Clients</Button>
        </div>
      </div>

      <section className="rounded-2xl border border-border p-4 md:p-5 mt-6 bg-card">
        <div className="grid gap-3 md:grid-cols-12 items-end">
          <div className="md:col-span-4">
            <label className="block text-sm font-medium">Search</label>
            <div className="mt-2 flex items-center gap-2 rounded-md border border-input bg-background px-3 py-2">
              <Search className="h-4 w-4 text-foreground/60" />
              <input value={q} onChange={(e) => setQ(e.target.value)} className="flex-1 bg-transparent outline-none" placeholder="Try: Next.js, Data Science, Design" />
            </div>
          </div>
          <div className="md:col-span-3">
            <label className="block text-sm font-medium">Skills</label>
            <input value={skills} onChange={(e) => setSkills(e.target.value)} className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" placeholder="Comma separated" />
            {skillList.length > 0 && (
              <div className="mt-1 text-xs text-foreground/60">{skillList.join(", ")}</div>
            )}
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium">Location</label>
            <div className="mt-2 flex items-center gap-2 rounded-md border border-input bg-background px-3 py-2">
              <MapPin className="h-4 w-4 text-foreground/60" />
              <input value={location} onChange={(e) => setLocation(e.target.value)} className="flex-1 bg-transparent outline-none" placeholder="Remote, NYC, EU" />
            </div>
          </div>
          <div className="md:col-span-1">
            <label className="block text-sm font-medium">Min Rating</label>
            <input type="number" min={0} max={5} step={0.1} value={minRating} onChange={(e) => setMinRating(Number(e.target.value))} className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" />
          </div>
          <div className="md:col-span-2 grid grid-cols-2 gap-2 items-end">
            <div>
              <label className="block text-sm font-medium">Available</label>
              <select className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" value={String(available)} onChange={(e) => setAvailable(e.target.value === "undefined" ? undefined : e.target.value === "true") }>
                <option value="undefined">Any</option>
                <option value="true">Yes</option>
                <option value="false">No</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium">Sort</label>
              <select className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" value={sort} onChange={(e) => setSort(e.target.value as any)}>
                <option value="rating_desc">Top Rated</option>
                <option value="rating_asc">Lowest Rated</option>
                <option value="rate_desc">Highest Rate</option>
                <option value="rate_asc">Lowest Rate</option>
                <option value="newest">Newest</option>
              </select>
            </div>
          </div>
          <div className="md:col-span-12"><div className="text-xs text-foreground/60 mt-2">{mode === "freelancers" ? `Results: ${data.total}` : `Results: ${CLIENTS.length}`}</div></div>
        </div>
      </section>

      {mode === "freelancers" ? (
        <>
          {error && <div className="mt-4 text-sm text-red-600">{error}</div>}
          <section className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {loading && data.items.length === 0 && Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-48 rounded-xl border border-border bg-card animate-pulse" />
            ))}
            {data.items.map((f) => (
              <article key={f._id || f.id} className="rounded-xl border border-border bg-card p-5 flex flex-col">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="font-semibold">{f.name}</div>
                    <div className="text-sm text-foreground/70">{f.title}</div>
                    <div className="mt-1 text-xs text-foreground/60">{f.location}</div>
                  </div>
                  <Stars value={f.rating} />
                </div>
                <div className="mt-3 text-sm text-foreground/80 line-clamp-3">{f.bio}</div>
                <div className="mt-3 flex flex-wrap gap-2 text-xs">
                  {f.skills.map((s) => (
                    <span key={s} className="rounded-md border border-border bg-background px-2 py-1">{s}</span>
                  ))}
                </div>
                <div className="mt-4 flex items-center justify-between gap-2">
                  <div className={`text-xs ${f.isAvailable ? "text-emerald-600" : "text-foreground/60"}`}>{f.isAvailable ? "Available now" : "Not available"}</div>
                  <div className="text-sm font-medium">${""}{f.hourlyRate}/hr</div>
                </div>
                <div className="mt-3 flex gap-2">
                  <Button className="bg-gradient-to-r from-primary to-purple-600">View Profile</Button>
                  <Button variant="outline">Contact</Button>
                </div>
              </article>
            ))}
          </section>
          <div className="mt-6 flex items-center justify-between">
            <div className="text-sm text-foreground/70">Page {data.page} of {totalPages}</div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}><ChevronLeft className="h-4 w-4" /></Button>
              <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages}><ChevronRight className="h-4 w-4" /></Button>
              <select className="ml-2 rounded-md border border-input bg-background px-2 py-1 text-sm" value={limit} onChange={(e) => setLimit(Number(e.target.value))}>
                {[6, 12, 24, 48].map((n) => <option key={n} value={n}>{n}/page</option>)}
              </select>
            </div>
          </div>
        </>
      ) : (
        <section className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {CLIENTS.map((c: any) => (
            <article key={c.id} className="rounded-xl border border-border bg-card p-5 flex flex-col">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{c.company}</div>
                  <div className="text-sm text-foreground/70">Focus: {c.focus.join(", ")}</div>
                  <div className="mt-1 text-xs text-foreground/60">{c.location}</div>
                </div>
                <Stars value={c.rating} />
              </div>
              <div className="mt-3 text-sm text-foreground/80 line-clamp-3">{c.about}</div>
              <div className="mt-4 flex gap-2">
                <Button className="bg-gradient-to-r from-primary to-purple-600">Open Profile</Button>
                <Button variant="outline">Open Projects</Button>
              </div>
            </article>
          ))}
        </section>
      )}
    </main>
  );
}
