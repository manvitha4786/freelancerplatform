import { useEffect, useMemo, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import type { ChatMessage } from "@shared/api";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

function useSocket(userId: string) {
  const socketRef = useRef<Socket | null>(null);
  useEffect(() => {
    const s = io("", { path: "/socket.io", transports: ["websocket"], auth: { userId } });
    socketRef.current = s;
    return () => {
      s.disconnect();
      socketRef.current = null;
    };
  }, [userId]);
  return socketRef;
}

export default function Messages() {
  const userId = useMemo(() => localStorage.getItem("demo_user") || `u_${Math.random().toString(36).slice(2, 8)}`, []);
  useEffect(() => localStorage.setItem("demo_user", userId), [userId]);

  const roomId = "general"; // demo room
  const socketRef = useSocket(userId);
  const [history, setHistory] = useState<ChatMessage[]>([]);
  const [text, setText] = useState("");
  const scrollerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const s = socketRef.current;
    if (!s) return;
    s.emit("room:join", roomId);

    const onHistory = (msgs: ChatMessage[]) => setHistory(msgs);
    const onNew = (msg: ChatMessage) => {
      setHistory((h) => [...h, msg]);
      if (msg.senderId !== userId) toast.info("New message", { description: msg.body });
    };
    const onRead = ({ messageId, userId: reader }: { messageId: string; userId: string }) => {
      setHistory((h) => h.map((m) => (m.id === messageId ? { ...m, readBy: Array.from(new Set([...(m.readBy || []), reader])) } : m)));
    };

    s.on("room:history", onHistory);
    s.on("message:new", onNew);
    s.on("message:read", onRead);
    return () => {
      s.off("room:history", onHistory);
      s.off("message:new", onNew);
      s.off("message:read", onRead);
    };
  }, [socketRef, roomId, userId]);

  useEffect(() => {
    scrollerRef.current?.lastElementChild?.scrollIntoView({ behavior: "smooth" });
  }, [history.length]);

  const send = () => {
    const s = socketRef.current;
    if (!s || !text.trim()) return;
    s.emit("message:send", { roomId, body: text.trim() });
    setText("");
  };

  const markSeen = (id: string) => socketRef.current?.emit("message:read", { roomId, messageId: id });

  return (
    <main className="container py-8">
      <div className="grid md:grid-cols-[260px_1fr] gap-6 min-h-[60vh]">
        <aside className="rounded-xl border border-border p-4">
          <div className="font-semibold">Chats</div>
          <div className="mt-3 text-sm text-foreground/70">General room</div>
        </aside>
        <section className="rounded-xl border border-border flex flex-col">
          <div className="px-4 py-3 border-b border-border font-semibold">Room: general</div>
          <div ref={scrollerRef} className="flex-1 overflow-y-auto p-4 space-y-3">
            {history.map((m) => {
              const mine = m.senderId === userId;
              const seen = (m.readBy || []).length > 1;
              return (
                <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`} onMouseEnter={() => markSeen(m.id)}>
                  <div className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${mine ? "bg-primary text-primary-foreground" : "bg-accent"}`}>
                    <div>{m.body}</div>
                    <div className="mt-1 text-[10px] opacity-80 text-right">{new Date(m.ts).toLocaleTimeString()} {mine ? (seen ? "✓✓" : "✓") : null}</div>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="p-3 border-t border-border flex gap-2">
            <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Type a message" className="flex-1 rounded-md border border-input bg-background px-3 py-2" />
            <Button onClick={send} className="bg-gradient-to-r from-primary to-purple-600">Send</Button>
          </div>
        </section>
      </div>
    </main>
  );
}
