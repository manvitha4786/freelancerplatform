import { Hero } from "@/components/home/Hero";
import { Features } from "@/components/home/Features";
import { Categories } from "@/components/home/Categories";
import { HowItWorks } from "@/components/home/HowItWorks";
import { CTA } from "@/components/home/CTA";

export default function Index() {
  return (
    <main>
      <Hero />
      <Features />
      <Categories />
      <HowItWorks />
      <CTA />
    </main>
  );
}
