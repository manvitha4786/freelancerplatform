import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { AuthLayout } from "@/components/auth/AuthLayout";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";

const schema = z.object({
  email: z.string().email("Enter a valid email"),
  password: z.string().min(6, "Minimum 6 characters"),
});

type Values = z.infer<typeof schema>;

export default function Login() {
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<Values>({ resolver: zodResolver(schema) });

  const onSubmit = async (v: Values) => {
    await new Promise((r) => setTimeout(r, 400));
    localStorage.setItem("demo_user_email", v.email);
    toast.success("Signed in", { description: `Welcome back, ${v.email}` });
    navigate("/dashboard");
  };

  return (
    <AuthLayout title="Sign in" subtitle="Welcome back! Continue your journey with Collabify." footer={<span>New here? <Link to="/register" className="text-primary hover:underline">Join Now</Link></span>}>
      <form onSubmit={handleSubmit(onSubmit)} className="grid gap-5">
        <div>
          <label className="block text-sm font-medium">Email</label>
          <input {...register("email")} type="email" className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" placeholder="you@company.com" />
          {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>}
        </div>
        <div>
          <label className="block text-sm font-medium">Password</label>
          <input {...register("password")} type="password" className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" placeholder="••••••••" />
          {errors.password && <p className="mt-1 text-sm text-red-600">{errors.password.message}</p>}
          <div className="mt-2 text-xs"><Link to="/help" className="text-foreground/70 hover:underline">Forgot password?</Link></div>
        </div>
        <div className="flex items-center gap-3">
          <Button type="submit" disabled={isSubmitting} className="bg-gradient-to-r from-primary to-purple-600">{isSubmitting ? "Signing in..." : "Sign In"}</Button>
          <Link to="/register"><Button type="button" variant="outline">Join Now</Button></Link>
        </div>
      </form>
    </AuthLayout>
  );
}
