import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import type { Category, CategoriesListResponse } from "@shared/api";
import { Globe, Smartphone, Palette, Brain, BarChart3, Megaphone, FolderOpen } from "lucide-react";

const ICONS: Record<string, any> = { Globe, Smartphone, Palette, Brain, BarChart3, Megaphone };

export default function CategoriesPage() {
  const [items, setItems] = useState<Category[]>([]);
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<"trending" | "popular" | "name">("trending");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const h = setTimeout(async () => {
      try {
        setLoading(true);
        setError(null);
        const params = new URLSearchParams();
        if (q) params.set("q", q);
        params.set("sort", sort);
        params.set("limit", "60");
        const resp = await fetch(`/api/categories?${params.toString()}`);
        if (!resp.ok) throw new Error(`Request failed: ${resp.status}`);
        const json = (await resp.json()) as CategoriesListResponse;
        setItems(json.items);
      } catch (e: any) {
        setError(e.message || "Failed to load categories");
      } finally {
        setLoading(false);
      }
    }, 250);
    return () => clearTimeout(h);
  }, [q, sort]);

  const filtered = useMemo(() => items, [items]);

  return (
    <main className="container py-10">
      <div className="flex items-end justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Explore Categories</h1>
          <p className="text-foreground/70 mt-1">Discover trending project areas and top talent.</p>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/post"><Button className="bg-gradient-to-r from-primary to-purple-600">Post a Project</Button></Link>
        </div>
      </div>

      <section className="rounded-2xl border border-border p-4 md:p-5 mt-6 bg-card">
        <div className="grid gap-3 md:grid-cols-12 items-end">
          <div className="md:col-span-6">
            <label className="block text-sm font-medium">Search categories</label>
            <input value={q} onChange={(e) => setQ(e.target.value)} className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" placeholder="e.g. Web Development, AI, Marketing" />
          </div>
          <div className="md:col-span-3">
            <label className="block text-sm font-medium">Sort by</label>
            <select value={sort} onChange={(e) => setSort(e.target.value as any)} className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2">
              <option value="trending">Trending</option>
              <option value="popular">Most Popular</option>
              <option value="name">Name (A-Z)</option>
            </select>
          </div>
          <div className="md:col-span-12">
            <div className="text-xs text-foreground/60 mt-2">{filtered.length} categories</div>
          </div>
        </div>
      </section>

      <section className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {loading && filtered.length === 0 && Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="h-40 rounded-xl border border-border bg-card animate-pulse" />
        ))}
        {filtered.map((c) => {
          const Icon = ICONS[c.icon] || FolderOpen;
          const gradient = { backgroundImage: `linear-gradient(to bottom right, ${c.colorFrom}, ${c.colorTo})` } as React.CSSProperties;
          return (
            <article key={c.slug} className="relative overflow-hidden rounded-xl border border-border bg-card p-5 flex flex-col">
              <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full opacity-20" style={gradient} />
              <div className="relative flex items-center gap-3">
                <div className="h-9 w-9 rounded-md text-white grid place-items-center" style={gradient}><Icon className="h-4 w-4" /></div>
                <div>
                  <div className="font-semibold">{c.name}</div>
                  <div className="text-xs text-foreground/70">{c.projectCount.toLocaleString()} projects • {c.hireCount.toLocaleString()} hires</div>
                </div>
              </div>
              <div className="relative mt-3 text-sm text-foreground/80 line-clamp-3">{c.description}</div>
              <div className="mt-4 flex gap-2">
                <Button onClick={async () => { try { await fetch(`/api/categories/${c.slug}/track`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: "hire" }) }); } catch {} finally { navigate(`/browse?mode=freelancers&skills=${encodeURIComponent(c.name)}`); } }} className="bg-gradient-to-r from-primary to-purple-600">Hire talent</Button>
                <Button variant="outline" onClick={async () => { try { await fetch(`/api/categories/${c.slug}/track`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: "project" }) }); } catch {} finally { navigate(`/post?category=${encodeURIComponent(c.slug)}`); } }}>Post project</Button>
              </div>
            </article>
          );
        })}
      </section>
    </main>
  );
}
