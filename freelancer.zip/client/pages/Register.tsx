import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { AuthLayout } from "@/components/auth/AuthLayout";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";

const schema = z.object({
  name: z.string().min(2, "Enter your name"),
  email: z.string().email("Enter a valid email"),
  password: z.string().min(6, "Minimum 6 characters"),
  role: z.enum(["freelancer", "client"], { required_error: "Select a role" }),
  terms: z.literal(true, { errorMap: () => ({ message: "You must accept the terms" }) }),
});

type Values = z.infer<typeof schema>;

export default function Register() {
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors, isSubmitting }, watch } = useForm<Values>({ resolver: zodResolver(schema), defaultValues: { role: "freelancer" as const } });

  const onSubmit = async (v: Values) => {
    await new Promise((r) => setTimeout(r, 500));
    localStorage.setItem("demo_user_email", v.email);
    localStorage.setItem("demo_user_name", v.name);
    localStorage.setItem("demo_user_role", v.role);
    toast.success("Account created", { description: `Welcome, ${v.name}!` });
    navigate("/dashboard");
  };

  const role = watch("role");

  return (
    <AuthLayout title="Join Collabify" subtitle="Create your account and start collaborating today." footer={<span>Already have an account? <Link to="/login" className="text-primary hover:underline">Sign In</Link></span>}>
      <form onSubmit={handleSubmit(onSubmit)} className="grid gap-5">
        <div>
          <label className="block text-sm font-medium">Full name</label>
          <input {...register("name")} className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" placeholder="Alex Doe" />
          {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>}
        </div>
        <div>
          <label className="block text-sm font-medium">Email</label>
          <input {...register("email")} type="email" className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" placeholder="you@company.com" />
          {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>}
        </div>
        <div>
          <label className="block text-sm font-medium">Password</label>
          <input {...register("password")} type="password" className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2" placeholder="••••••••" />
          {errors.password && <p className="mt-1 text-sm text-red-600">{errors.password.message}</p>}
        </div>
        <div>
          <label className="block text-sm font-medium">I am a</label>
          <div className="mt-2 grid grid-cols-2 gap-3">
            <label className={`rounded-md border px-3 py-2 cursor-pointer text-center ${role === "freelancer" ? "border-primary ring-1 ring-primary" : "border-input"}`}>
              <input type="radio" value="freelancer" {...register("role")} className="hidden" /> Freelancer
            </label>
            <label className={`rounded-md border px-3 py-2 cursor-pointer text-center ${role === "client" ? "border-primary ring-1 ring-primary" : "border-input"}`}>
              <input type="radio" value="client" {...register("role")} className="hidden" /> Client
            </label>
          </div>
          {errors.role && <p className="mt-1 text-sm text-red-600">{errors.role.message}</p>}
        </div>
        <div className="flex items-center gap-2">
          <input id="terms" type="checkbox" {...register("terms")} className="h-4 w-4" />
          <label htmlFor="terms" className="text-sm">I agree to the <Link to="/terms" className="underline">Terms</Link> and <Link to="/privacy" className="underline">Privacy</Link>.</label>
        </div>
        {errors.terms && <p className="-mt-3 text-sm text-red-600">{errors.terms.message}</p>}
        <div className="flex items-center gap-3">
          <Button type="submit" disabled={isSubmitting} className="bg-gradient-to-r from-primary to-purple-600">{isSubmitting ? "Creating..." : "Join Now"}</Button>
          <Link to="/login"><Button type="button" variant="outline">Sign In</Button></Link>
        </div>
      </form>
    </AuthLayout>
  );
}
